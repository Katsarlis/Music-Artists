package com.sampled.musicartists;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;


public class ArtistAdapter extends BaseAdapter {
    Context context;
    LayoutInflater layoutInflater;
    ArrayList<Artist> artistsList;



    public ArtistAdapter(Context context,ArrayList<Artist> artistsList){
        this.context=context;
        this.artistsList=artistsList;
    }


    @Override
    public int getCount() {
        return artistsList.size();
    }

    @Override
    public Object getItem(int position) {
        return artistsList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return artistsList.get(position).id;
    }

    class ViewHolder{
        private ImageView imageView;
        private TextView nameTextView;
        private TextView genresTextView;
        private TextView albumsTextView;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder=null;
        if (convertView==null) {
            layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView=layoutInflater.inflate(R.layout.item,parent,false);
            viewHolder = new ViewHolder();
            viewHolder.imageView = (ImageView)convertView.findViewById(R.id.imageView);
            viewHolder.nameTextView =(TextView)convertView.findViewById(R.id.nameTextView);
            viewHolder.genresTextView=(TextView)convertView.findViewById(R.id.genresTextView);
            viewHolder.albumsTextView = (TextView)convertView.findViewById(R.id.albumsTextView);
            convertView.setTag(viewHolder);

        } else {
            viewHolder = (ViewHolder)convertView.getTag();
        }
        Artist artist = artistsList.get(position);
        viewHolder.imageView.setImageResource(R.drawable.music);
        viewHolder.nameTextView.setText(artist.name);
        viewHolder.genresTextView.setText(artist.genres);
        viewHolder.albumsTextView.setText(artist.albums+" albums, "+artist.tracks+" tracks");







        return convertView;
    }



}