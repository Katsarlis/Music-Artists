package com.sampled.musicartists;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.ListActivity;
import android.app.ListFragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    ListView listView;
    ArtistAdapter adapter;
    ArrayList<Artist> artistsList;
    DBHelper helper;


    public static String LOG_TAG = "my_log";

    public boolean isOnline() {
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = (ListView) findViewById(R.id.listView);
        helper = new DBHelper(this);


        if (!helper.isTableExists()&&isOnline()) {
            new ParseData().execute();
        } else {
            ArrayList<Artist> artists = helper.getArtists();
            adapter = new ArtistAdapter(MainActivity.this, artists);
            listView.setAdapter(adapter);
            listView.setOnItemClickListener(this);

        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Log.d(LOG_TAG, "CLICKED " + position + "  " + id);
        Intent intent = new Intent();
        intent.setClass(this,DetailsActivity.class);
        intent.putExtra("index",position);
        startActivity(intent);
    }


    private class ParseData extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... params) {

            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;
            String resultJson = "";


            try {
                URL url = new URL("http://cache-spb09.cdn.yandex.net/download.cdn.yandex.net/mobilization-2016/artists.json");

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                InputStream inputStream = urlConnection.getInputStream();
                StringBuffer buffer = new StringBuffer();

                reader = new BufferedReader(new InputStreamReader(inputStream));

                String line;
                while ((line = reader.readLine()) != null) {
                    buffer.append(line);
                }

                resultJson = buffer.toString();

            } catch (Exception e) {
                e.printStackTrace();
            }


            try {
                artistsList = new ArrayList<Artist>();


                JSONArray dataJsonArray = new JSONArray(resultJson);


                for (int i = 0; i < dataJsonArray.length(); i++) {
                    Artist artist = new Artist();
                    JSONObject artistData = dataJsonArray.getJSONObject(i);
                    artist.id = artistData.getInt("id");
                    artist.name = artistData.getString("name");
                    JSONArray genres = artistData.getJSONArray("genres");
                    artist.genres = genres.toString();
                    artist.tracks = artistData.getInt("tracks");
                    artist.albums = artistData.getInt("albums");
                    JSONObject cover = artistData.getJSONObject("cover");
                    artist.small = cover.getString("small");
                    artist.big = cover.getString("big");

                    helper.addArtist(artist);

                }

            } catch (JSONException e) {
                e.printStackTrace();
            }


            return null;
        }

        @Override
        protected void onPostExecute(Void avoid) {
            super.onPostExecute(avoid);
            ArrayList<Artist> artistsList = helper.getArtists();
            adapter = new ArtistAdapter(MainActivity.this, artistsList);
            listView.setAdapter(adapter);
            listView.setOnItemClickListener(MainActivity.this);
        }
    }


    /*
    public static class ArtistsFragment extends ListFragment {
        boolean mDualPane;
        int mCurCheckPosition=0;


        @Override
        public void onActivityCreated(Bundle savedInstanceState) {
            super.onActivityCreated(savedInstanceState);
            setListAdapter(new ArtistAdapter(getActivity(), artis ));

            View detailsFrame = getActivity().findViewById(R.id.details);
            mDualPane = detailsFrame !=null && detailsFrame.getVisibility() == View.VISIBLE;

            if (savedInstanceState!=null){
                mCurCheckPosition = savedInstanceState.getInt("curChoice,0");
            }

            if (mDualPane){
                getListView().setChoiceMode(AbsListView.CHOICE_MODE_SINGLE);
                showDetails(mCurCheckPosition);
            }
        }

        @Override
        public void onSaveInstanceState(Bundle outState) {
            super.onSaveInstanceState(outState);
            outState.putInt("curChoice",mCurCheckPosition);
        }

        @Override
        public void onListItemClick(ListView l, View v, int position, long id) {
            showDetails(position);
        }

        void showDetails(int index) {
            mCurCheckPosition = index;

            if (mDualPane){
                getListView().setItemChecked(index,true);

                DetailsFragment details = (DetailsFragment)getFragmentManager().findFragmentById(R.id.details);
                if (details == null || details.getShownIndex()!=index){
                    details = DetailsFragment.newInstance(index);

                    FragmentTransaction ft = getFragmentManager().beginTransaction();
                    if (index ==0){
                        ft.replace(R.id.details,details);
                    } else {
                        ft.replace(R.id.artists,details);
                    }
                    ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                    ft.commit();
                }
            } else {
                Intent intent = new Intent();
                intent.setClass(getActivity(),DetailsActivity.class);
                intent.putExtra("index",index);
                startActivity(intent);
            }
        }
    }
    */
}
